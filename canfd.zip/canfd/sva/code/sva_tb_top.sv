`ifndef _SVA_TB_TOP_SV_
`define _SVA_TB_TOP_SV_

//=========================================================================
// sva_tb_top: TB 顶层断言
//   在 tb_top 层例化的全局断言
//=========================================================================

// 模式互斥检查: LBACK/SLEEP/SNOOP 不可同时为1
// 通过监测寄存器写入实现
logic [31:0] msr_shadow;
always @(posedge TopVif.clk) begin
    if (!TopVif.rstn)
        msr_shadow <= 32'h0;
    else if (TopVif.axi4litevif.awvalid && TopVif.axi4litevif.awready &&
             TopVif.axi4litevif.awaddr == 16'h0004)
        msr_shadow <= TopVif.axi4litevif.wdata;
end

// 断言: LBACK/SLEEP/SNOOP 互斥
assert property (@(posedge TopVif.clk) disable iff (!TopVif.rstn)
    (msr_shadow[1] + msr_shadow[2] + msr_shadow[0]) <= 1)
    else `uvm_error("SVA_TB", "LBACK/SLEEP/SNOOP mutually exclusive violation!");

// 断言: SRST 写1后自动清零
assert property (@(posedge TopVif.clk) disable iff (!TopVif.rstn)
    (TopVif.axi4litevif.awvalid && TopVif.axi4litevif.awready &&
     TopVif.axi4litevif.awaddr == 16'h0000 && TopVif.axi4litevif.wdata[0])
    |=> ##[1:5] !(TopVif.axi4litevif.rdata[0] && TopVif.axi4litevif.arvalid))
    else `uvm_warning("SVA_TB", "SRST not auto-cleared (informational)");

`endif
