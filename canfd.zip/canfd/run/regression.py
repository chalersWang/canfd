#!/usr/bin/env python3
"""
CANFD 验证回归测试管理脚本
用法:
  python3 regression.py --list          # 列出所有 testcase
  python3 regression.py --run T1        # 运行 T1 group
  python3 regression.py --run all       # 运行全部
  python3 regression.py --covmerge      # 合并覆盖率
  python3 regression.py --report        # 生成报告
"""
import argparse, json, os, subprocess, sys

VERIFY_HOME = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TESTPLAN_DIR = os.path.join(VERIFY_HOME, "testplan")
RUN_DIR = os.path.join(VERIFY_HOME, "run")

GROUPS = ["T1", "T2", "T3", "T4", "T5", "T6", "T7"]
GROUP_NAMES = {
    "T1": "寄存器访问",
    "T2": "CAN通信功能",
    "T3": "接收功能",
    "T4": "工作模式",
    "T5": "错误处理",
    "T6": "接口时序",
    "T7": "特殊功能+压力边界",
}

def list_tests():
    total = 0
    for g in GROUPS:
        jf = os.path.join(TESTPLAN_DIR, f"{g}_group", "test.json")
        with open(jf) as f:
            tests = json.load(f)
        print(f"\n{g} ({GROUP_NAMES[g]}): {len(tests)} tests")
        for t in sorted(tests.keys()):
            print(f"  - {t}")
        total += len(tests)
    print(f"\nTotal: {total} tests")

def run_group(group, with_cov=False, n_repeat=1):
    if group == "all":
        for g in GROUPS:
            run_group(g, with_cov, n_repeat)
        return
    jf = os.path.join(TESTPLAN_DIR, f"{group}_group", "test.json")
    with open(jf) as f:
        tests = json.load(f)
    print(f"\n{'='*60}")
    print(f"Running {group} ({GROUP_NAMES.get(group, '')}): {len(tests)} tests")
    print(f"{'='*60}")
    for tname in sorted(tests.keys()):
        cmd = [os.path.join(RUN_DIR, "xrun"), "-g", group, "-t", tname, "-s"]
        if with_cov:
            cmd.append("--cov")
        if n_repeat > 1:
            cmd.extend(["-n", str(n_repeat)])
        print(f"\n>>> {tname}")
        subprocess.run(cmd, cwd=RUN_DIR)

def merge_coverage():
    print("Merging coverage...")
    subprocess.run([os.path.join(RUN_DIR, "xrun"), "--covmerge"], cwd=RUN_DIR)

def gen_report():
    print("Opening coverage report...")
    subprocess.run([os.path.join(RUN_DIR, "xrun"), "--opencov"], cwd=RUN_DIR)

if __name__ == "__main__":
    p = argparse.ArgumentParser(description="CANFD Regression Manager")
    p.add_argument("--list", action="store_true", help="List all testcases")
    p.add_argument("--run", type=str, help="Run group (T1-T7 or all)")
    p.add_argument("--cov", action="store_true", help="Enable coverage")
    p.add_argument("--n", type=int, default=1, help="Repeat count")
    p.add_argument("--covmerge", action="store_true", help="Merge coverage")
    p.add_argument("--report", action="store_true", help="Open coverage report")
    args = p.parse_args()

    if args.list: list_tests()
    elif args.run: run_group(args.run, args.cov, args.n)
    elif args.covmerge: merge_coverage()
    elif args.report: gen_report()
    else: p.print_help()
